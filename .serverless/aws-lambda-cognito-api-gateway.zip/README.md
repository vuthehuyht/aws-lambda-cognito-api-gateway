# AWS Lambda + Cognito + API Gateway

Demo rest api xac thuc su dung serverless + API Gateway + Cognito